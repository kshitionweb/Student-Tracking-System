﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Student_Tracking_System.Pages
{
    public partial class Forget_Password : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        protected void Page_Load(object sender, EventArgs e)
        {
            conn.Open();
        }

        protected void btnForgetPasswordBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("BeforeLoginPage.aspx");
        }

        protected void btnCheckID_Click(object sender, EventArgs e)
        {
            string checkuser = "select * from Student_Table where student_id='" + txtForgetId.Text + "'";
            SqlCommand cmd = new SqlCommand(checkuser, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                lblForgetSecQue.Text = sdr[15].ToString();
                lblForgetSecQue.Visible = true;
                txtForgetPwdSecAns.Visible = true;
                txtStudentPassword.Visible = true;
                btnForgetPassword.Visible = true;
            }
            sdr.Close();
        }
        protected void btnForgetPassword_Click(object sender, EventArgs e)
        {
            string checkuser = "select * from Student_Table where student_id='" + txtForgetId.Text + "'";
            SqlCommand cmd = new SqlCommand(checkuser, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                if(txtForgetPwdSecAns.Text == sdr[16].ToString())
                {
                    string update_student_pwd = "update Student_Table set student_password = '" + txtStudentPassword.Text + "' where student_id = '" + txtForgetId.Text + "'";
                    cmd = new SqlCommand(update_student_pwd, conn);

                    cmd.ExecuteNonQuery();
                    
                    ClientScript.RegisterStartupScript(Page.GetType(), "Message", "alert('" + "Your Password is changed" + "');", true);
                }
                else
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "Message", "alert('" + "Your Security Answer Does not Match" + "');", true);
                }
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Message", "alert('" + "Wrong Credentials" + "');", true);
            }
            sdr.Close();
        }

        
    }
}