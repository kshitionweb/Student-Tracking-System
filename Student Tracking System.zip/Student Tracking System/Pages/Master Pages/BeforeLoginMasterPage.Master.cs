﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Tracking_System.Pages.Master_Pages
{
    public partial class BeforeLoginMasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void studentLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("BeforeLoginStudent.aspx");
        }

        protected void registerLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("BeforeLoginDepartment.aspx");
        }

        protected void adminLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("BeforeLoginAdmin.aspx");
        }
    }
}