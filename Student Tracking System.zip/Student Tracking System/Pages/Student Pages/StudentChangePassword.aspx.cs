﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace Student_Tracking_System.Pages.Student_Pages
{
    public partial class StudentChangePassword : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnStudentChangePassword_Click(object sender, EventArgs e)
        {
            conn.Open();

            string update_student_pwd = "update Student_Table set student_password = '" + inputPasswordNew.Text + "' where student_id = '" + Session["StudentID"].ToString() + "'";
            SqlCommand cmd = new SqlCommand(update_student_pwd, conn);

            cmd.ExecuteNonQuery();
        }
    }
}