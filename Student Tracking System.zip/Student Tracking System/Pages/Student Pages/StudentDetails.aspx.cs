﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace Student_Tracking_System.Pages.Student_Pages
{
    public partial class StudentDetails : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

        protected void Page_Load(object sender, EventArgs e)
        {
            conn.Open();
            if (!IsPostBack)
            {
                //string filename = Session["StudentID"].ToString();
                //img2.ImageUrl = "~/ProfileImages//" + filename;
                string student_details = "select * from Student_Table where student_id='" + Session["StudentID"].ToString() + "'";
                SqlCommand cmd = new SqlCommand(student_details, conn);
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    lblStudent_id.Text = Session["StudentID"].ToString();
                    lblStudent_first_name.Text = sdr[1].ToString();
                    lblStudent_last_name.Text = sdr[2].ToString();
                    lblStudent_email.Text = sdr[3].ToString();
                    lblStudent_contact.Text = sdr[4].ToString();
                    lblStudent_dob.Text = sdr[5].ToString();
                    lblStudent_course.Text = sdr[6].ToString();
                    lblStudent_study_period.Text = sdr[7].ToString();
                    lblStudent_further_education.Text = sdr[8].ToString();
                    lblStudent_state.Text = sdr[9].ToString();
                    lblStudent_city.Text = sdr[10].ToString();
                    lblStudentPinCode.Text = sdr[11].ToString();
                    lblStudent_workingAt.Text = sdr[12].ToString();
                    lblStudent_jobType.Text = sdr[13].ToString();

                    txtStudentFirstName.Text = sdr[1].ToString();
                    txtStudentLastName.Text = sdr[2].ToString();
                    txtStudentEmail.Text = sdr[3].ToString();
                    txtStudentContactNumber.Text = sdr[4].ToString();
                    txtStudentFurtherEducation.Text = sdr[8].ToString();
                    txtStudentState.Text = sdr[9].ToString();
                    txtStudentCity.Text = sdr[10].ToString();
                    txtStudentPinCode.Text = sdr[11].ToString();
                    txtStudentWorking.Text = sdr[12].ToString();
                    txtStudentJobType.Text = sdr[13].ToString();
                }
                sdr.Close();
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string update_student_details = "update Student_Table set student_first_name = '" + txtStudentFirstName.Text + "', student_last_name = '" + txtStudentLastName.Text + "' , student_email = '" + txtStudentEmail.Text + "', student_contact = '" + txtStudentContactNumber.Text + "', student_further_education = '" + txtStudentFurtherEducation.Text + "', student_state = '" + txtStudentState.Text + "', student_city = '" + txtStudentCity.Text + "', student_pincode = '" + txtStudentPinCode.Text + "', student_currently_working = '" + txtStudentWorking.Text + "', student_job_type = '" + txtStudentJobType.Text + "' where student_id = '" + Session["StudentID"].ToString() + "'";
            SqlCommand cmd = new SqlCommand(update_student_details, conn);

            cmd.ExecuteNonQuery();
        }
    }
}