﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Student_Tracking_System.Pages
{
    public partial class BeforeRegisterPage : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        protected void Page_Load(object sender, EventArgs e)
        {
            conn.Open();
            if (!IsPostBack)
            {
            }
        }

        protected void btnRegisterStudent_Click(object sender, EventArgs e)
        {
            string fetch_student_details = "select * from Student_Table where student_id='" + txtRegisterStudentNumber.Text + "' or student_email='"+txtRegisterStudentEmail.Text+"'";
            SqlCommand cmd = new SqlCommand(fetch_student_details, conn);
            SqlDataReader sdr = cmd.ExecuteReader();

            while (sdr.Read())
            {
                if (txtRegisterStudentNumber.Text == sdr[0].ToString() && txtRegisterStudentEmail.Text == sdr[3].ToString())
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "Message", "alert('" + "Student ID and Email Already Exists" + "');", true);
                } 
                else if(txtRegisterStudentNumber.Text == sdr[0].ToString())
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "Message", "alert('" + "Student ID Already Exists" + "');", true);
                }
                else if(txtRegisterStudentEmail.Text == sdr[3].ToString())
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "Message", "alert('" + "Email Already Exists" + "');", true);
                }
                else
                {
                        string register_student = "insert into Student_Table values (@student_id,@student_first_name,@student_last_name,@student_email,@student_contact,@student_dob,@student_course,@student_passout_year,@student_further_education,@student_state,@student_city,@student_pincode,@student_currently_working,@student_job_type,@student_password,@student_sec_que,@student_sec_ans)";
                        cmd = new SqlCommand(register_student, conn);
                        cmd.Parameters.AddWithValue("@student_id", txtRegisterStudentNumber.Text);
                        cmd.Parameters.AddWithValue("@student_first_name", txtRegisterFirstName.Text);
                        cmd.Parameters.AddWithValue("@student_last_name", txtRegisterLastName.Text);
                        cmd.Parameters.AddWithValue("@student_email", txtRegisterStudentEmail.Text);
                        cmd.Parameters.AddWithValue("@student_contact", 0);
                        cmd.Parameters.AddWithValue("@student_dob", "N/A");
                        cmd.Parameters.AddWithValue("@student_course", "N/A");
                        cmd.Parameters.AddWithValue("@student_passout_year", 0000);
                        cmd.Parameters.AddWithValue("@student_further_education", "N/A");
                        cmd.Parameters.AddWithValue("@student_state", "N/A");
                        cmd.Parameters.AddWithValue("@student_city", "N/A");
                        cmd.Parameters.AddWithValue("@student_pincode", "N/A");
                        cmd.Parameters.AddWithValue("@student_currently_working", "N/A");
                        cmd.Parameters.AddWithValue("@student_job_type", "N/A");
                        cmd.Parameters.AddWithValue("@student_password", txtRegisterStudentPassword.Text);
                        cmd.Parameters.AddWithValue("@student_sec_que", ddlSecQue.SelectedItem.Text.ToString());
                        cmd.Parameters.AddWithValue("@student_sec_ans", txtRegisterStudentSecAns.Text);

                        cmd.ExecuteNonQuery();
                        lblMsg.Text = "You are now registered. Please login.";

                        conn.Close();
                    }
                }
            }
    }
}