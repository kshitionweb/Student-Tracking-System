﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace Student_Tracking_System.Pages
{
    public partial class BeforeLoginPage : System.Web.UI.Page
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        protected void Page_Load(object sender, EventArgs e)
        {
            conn.Open();
        }

        protected void btnLoginStudent_Click(object sender, EventArgs e)
        {
            string checkuser = "select * from Student_Table where student_id='" + txtLoginStudentNumber.Text + "' and student_password = '"+txtLoginStudentPassword.Text+"'";
            SqlCommand cmd = new SqlCommand(checkuser, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                Session["StudentID"] = txtLoginStudentNumber.Text;
                Response.Redirect("~/Pages/Student Pages/StudentAnnouncements.aspx");
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Message", "alert('" + "Wrong Credentials" + "');", true);
            }

            conn.Close();
            
        }

        protected void btnLoginDepartment_Click(object sender, EventArgs e)
        {
            string checkuser = "select * from Admin_Table where admin_id='" + txtLoginDepartmentId.Text + "' and admin_password = '" + txtLoginDepartmentPassword.Text + "'";
            SqlCommand cmd = new SqlCommand(checkuser, conn);
            SqlDataReader sdr = cmd.ExecuteReader();

            if (sdr.Read())
            {
                Session["AdminID"] = txtLoginDepartmentId.Text;
                Response.Redirect("~/Pages/Department Admin Pages/AdminEvents.aspx");
            }
            else
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "Message", "alert('" + "Wrong Credentials" + "');", true);
            }
            conn.Close();
        }
    }
}